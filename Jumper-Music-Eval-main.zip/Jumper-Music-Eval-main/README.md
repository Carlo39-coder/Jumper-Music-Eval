# Jumper – Die faire Deutschrap & Hip-Hop Plattform

Monatliche Wettbewerbe mit echtem Fokus auf Musikgeschichte, Kreativität und Community – nicht nur Klicks!

### Features
- Künstler melden sich mit Tracks an
- Bewertung nach anpassbaren Kriterien (Historischer Bezug hat höchstes Gewicht)
- Extra-Bonus für junge Künstler (< 25 Jahre)
- Mentor-System für etablierte Artists
- 100 % Open Source

### Installation (wenn jemand mitmachen will)
```bash
pip install flask
python app.py
